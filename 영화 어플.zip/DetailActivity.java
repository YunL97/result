package com.example.movie;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;

//MyRecyclerViewAdapter Activity 에서 Intent로 보낸것을 받아서 상세화면에 보여주는 Activity
public class DetailActivity extends AppCompatActivity {

    MyDBHelper myHelper;
    MyDBHelper2 myHelper2;
    SQLiteDatabase sqlDB,sqlDB2;
    Button btnInsert,btnSelect;
    EditText edtGName;
    TextView txtGNameResult,Super,Actor,textView_overview;
    ListView listV;
    String Ttitle,Super1,Actor1,Text1;
    SimpleAdapter adapter;
    View dialogView;

    Login log;
    String b,d;
    int c;

    ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();
    HashMap<String,String> item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        btnInsert = findViewById(R.id.btnInsert);
        btnSelect = findViewById(R.id.btnSelect);
        Super= findViewById(R.id.txtSuper);
        Actor=findViewById(R.id.txtActor);

        //edtGName = findViewById(R.id.edtName);

        //txtGNameResult= findViewById(R.id.txtGNameResult);
        listV = findViewById(R.id.listV);

        Intent intent = getIntent();

        //MainActivity에서 보내준값 받아오는 코드
        Ttitle = intent.getStringExtra("title");
        String original_title = intent.getStringExtra("original_title");
        String poster_path = intent.getStringExtra("poster_path");
        String overview = intent.getStringExtra("overview");
        String release_date = intent.getStringExtra("release_date");

        TextView textView_title = (TextView)findViewById(R.id.tv_title);
        textView_title.setText("제목: "+Ttitle);
        TextView textView_original_title = (TextView)findViewById(R.id.tv_original_title);
        textView_original_title.setText("부제: "+original_title);
        ImageView imageView_poster = (ImageView) findViewById(R.id.iv_poster);



        //MyDBHelper 객체 생성
        myHelper = new MyDBHelper(getApplication(), "groupDB", null,1);
        myHelper2 = new MyDBHelper2(getApplication(),"groupDB2",null,1);

        Glide.with(this)
                .load(poster_path)
                .centerCrop()
                .crossFade()
                .into(imageView_poster); //이미지 로딩할때 사용

        textView_overview  = (TextView)findViewById(R.id.tv_overview);
        //textView_overview.setText(overview);
        TextView textView_release_date = (TextView)findViewById(R.id.tv_release_date);
        textView_release_date.setText("개봉날짜 :"+release_date);

        if(log.getId().equals("admin")) {
            btnInsert.setVisibility(View.INVISIBLE);
        }else{
            btnInsert.setVisibility(View.INVISIBLE);
        }

        //감독,배우,영화 내용 DB에 넣기 위한 버튼코드
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    dialogView = View.inflate(DetailActivity.this,R.layout.insert,null);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(DetailActivity.this);
                    dlg.setTitle("데이터 넣기");
                    dlg.setView(dialogView);
                    dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            try {
                                EditText edtSuper=(EditText)dialogView.findViewById(R.id.edtSuper);
                                EditText edtActor=(EditText)dialogView.findViewById(R.id.edtActor);
                                EditText edtText=(EditText)dialogView.findViewById(R.id.edtText);

                                sqlDB2 = myHelper2.getWritableDatabase();
                                String sql = "insert into groupTBL2(gtitle,gsuper,gactor,gtext) values(?,?,?,?);";//insert문
                                Object[] bindArgs = {Ttitle,edtSuper.getText().toString(),edtActor.getText().toString(),edtText.getText().toString()};//insert문 (?,?)에 해당하는 값

                                sqlDB2.execSQL(sql,bindArgs);

                                Toast.makeText(getApplicationContext(), "입력되었습니다", Toast.LENGTH_SHORT).show();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), "입력실패했습니다.", Toast.LENGTH_SHORT).show();
                            }
                            sqlDB2.close();
                        }
                    });
                    dlg.setNegativeButton("취소",null);
                    dlg.show();

            }
        });
        //댓글,평점내용 DB에 넣기위한 코드
       btnSelect.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               final String[] items = {"1", "2", "3","4","5"};
                  AlertDialog.Builder dlg = new AlertDialog.Builder(DetailActivity.this);
               dlg.setTitle("댓글 평점").setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener(){

                   // 목록 클릭시 설정

                   public void onClick(DialogInterface dialog, int index){
                       //Toast.makeText(getApplicationContext(), items[index], Toast.LENGTH_SHORT).show();
                        c=Integer.parseInt(items[index]);
                   }

               });
               final EditText name = new EditText(DetailActivity.this);
                dlg.setView(name);
                d= name.getText().toString();
//                버튼 클릭시 동작
               dlg.setPositiveButton("확인",new DialogInterface.OnClickListener(){
                   public void onClick(DialogInterface dialog, int which) {
                       //토스트 메시지
                      try {
                           //데이터베이스 읽고쓰기위해 getWritableDatabase() 사용
                           sqlDB = myHelper.getWritableDatabase();
                           String sql = "insert into groupTBL(gtitle,gname,gint) values(?,?,?);";//insert문
                           Object[] bindArgs = {Ttitle,name.getText().toString(),c};//insert문 (?,?)에 해당하는 값

                           //sqlDB.execSQL(sql);
                           sqlDB.execSQL(sql,bindArgs);
                           Toast.makeText(getApplicationContext(), "입력되었습니다", Toast.LENGTH_SHORT).show();
                       }catch (Exception e){
                           Toast.makeText(getApplicationContext(), "입력실패했습니다.", Toast.LENGTH_SHORT).show();
                       }


                       item= new HashMap<String,String>();
                       item.put("item1",name.getText().toString());
                       item.put("item2", "별점: "+c);
                       list.add(item);
                       sqlDB.close();
                       listV.deferNotifyDataSetChanged();
                       adapter.notifyDataSetChanged();
                   }
               });
               dlg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {
                   }
               });


               dlg.show();
           }


       });

        //데이터베이스 읽고쓰기위해 getWritableDatabase() 사용
        sqlDB=myHelper.getWritableDatabase();
        sqlDB2=myHelper2.getWritableDatabase();
        Cursor cursor,cursor1;//실질적으로 sql을 실행하는 객체,특정행을 가리키고 있는 포인터

        //rawQuery 메서드가 Cursor객체로 데이터 반환
        cursor= sqlDB.rawQuery("select * from groupTBL where gtitle='"+Ttitle+"'",null);//rawQuery 메서드가 Cursor객체로 데이터 반환
        cursor1= sqlDB2.rawQuery("select * from groupTBL2 where gtitle='"+Ttitle+"'",null);//rawQuery 메서드가 Cursor객체로 데이터 반환

        //select문이기 때문에 반복문 사용
        try {

            cursor1.moveToNext();
            Super1 = cursor1.getString(1);
            Actor1 = cursor1.getString(2);
            Text1 = cursor1.getString(3);

            Super.setText("  감독: "+Super1);
            Actor.setText("  배우: "+Actor1);
            textView_overview.setText(Text1);
        }catch (Exception e){

        }

        if(cursor!=null) {
            while (cursor.moveToNext()) {
                item= new HashMap<String,String>();
                b=cursor.getString(2);
                item.put("item1", b);
                item.put("item2", "별점: "+cursor.getInt(3));
                list.add(item);
            }
        }

            //관리자 로그인 했을때 댓글 내용 지우기 위한 listView 코드
            listV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    sqlDB = myHelper.getWritableDatabase();
                    String sql = "delete from groupTBL where gtitle=? and gname=?;";//insert문
                    Object[] bindArgs = {Ttitle, list.get(i).get("item1")};//insert문 (?,?)에 해당하는 값

                    if(log.getId().equals("admin")) {
                        sqlDB.execSQL(sql, bindArgs);
                    }
                    Toast.makeText(getApplicationContext(), "" + list.get(i).get("item1"), Toast.LENGTH_SHORT).show();

                    if(log.getId().equals("admin")) {
                        list.remove(i);
                    }
                    adapter = new SimpleAdapter(getApplicationContext(), list, android.R.layout.simple_list_item_2, new String[]{"item1", "item2"},
                            new int[]{android.R.id.text1, android.R.id.text2});
                    listV.setAdapter(adapter);

                    sqlDB.close();
                    adapter.notifyDataSetChanged();


                }
            });

        cursor.close();cursor1.close();
        sqlDB.close();sqlDB2.close();
         adapter = new SimpleAdapter(this, list,android.R.layout.simple_list_item_2,  new String[] {"item1","item2"},
                 new int[] {android.R.id.text1, android.R.id.text2});
        //listView에 가져온 값을 띄우기 위한 코드
        listV.setAdapter(adapter);// ArrayAdapter(this, 출력모양, 배열)
    }
}

