package com.example.movie;

//관리자 로그인 클래스 모든클래스에 같은값 나오게 하기위해 static 사용
public class Login {
    private static String id="a";
    private static String Pass;

    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        Login.id = id;
    }

    public static String getPass() {
        return Pass;
    }

    public static void setPass(String pass) {
        Pass = pass;
    }
}
